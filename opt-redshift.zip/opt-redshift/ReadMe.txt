Constraining power of cosmological observables: blind redshift spots and optimal ranges.

The Mathematica file "Figures 1-10 & 12-14.nb" contains the code as well as comments that produce Figures 1-10 & 12-14  of the paper. The zip file "ErrorBarLogPlots.zip" includes 
the appropriate files and the details you need to get the "Error Bar Log Plots" package that we use to construct Figure 13 (you can also download it directly from http://library.wolfram.com/infocenter/MathSource/6747/).
The Mathematica file entitled "Figure 11.nb" contains the code and the appropriate comments for the reproduction of Figure 11 and some extra plots. This file may need some time to run depending on your system.
All figures were produced using "Wolfram Mathematica 11.0".

If you use any of the above codes or the figures in a published work please cite our paper.

Any further questions/comments are welcome.

L. Kazantzidis <lkazantzi@cc.uoi.gr>
L. Perivolaropoulos <leandros@uoi.gr>
F. Skara <fskara@cc.uoi.gr>